import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Mail, ArrowLeft, MessageSquare, HelpCircle } from 'lucide-react';

function ForgotPassword() {
  const { forgotPassword, error, setError } = useAuth();
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState(null);

  // AI Help Widget State
  const [showHelp, setShowHelp] = useState(false);
  const [chatHistory, setChatHistory] = useState([
    {
      sender: 'assistant',
      text: 'Hello! I am your TaskCircle login assistant. How can I help you today? Please click on any of the questions below or ask a custom question.',
    },
  ]);

  const helpTopics = [
    {
      question: 'I forgot my password',
      answer: 'No worries! Enter your registered email address on this page and click "Send Reset Link". We will email you a secure link to reset your password.',
    },
    {
      question: 'How do I reset my password?',
      answer: 'After requesting a reset link, check your inbox for an email from TaskCircle. Click the link inside, enter your new password twice, and confirm.',
    },
    {
      question: 'I didn\'t receive the reset email',
      answer: 'Please check your spam or junk folder. Also ensure that you entered the correct email address associated with your TaskCircle account.',
    },
    {
      question: 'What should I do if my email is not recognized?',
      answer: 'Make sure there are no typos in the email address. If you originally signed up via Google or Phone OTP, try logging in with those methods instead.',
    },
  ];

  const handleHelpClick = (topic) => {
    setChatHistory((prev) => [
      ...prev,
      { sender: 'user', text: topic.question },
      { sender: 'assistant', text: topic.answer },
    ]);
  };

  const handleCustomQuestion = (e) => {
    e.preventDefault();
    const query = e.target.elements.customQuery.value.trim();
    if (!query) return;

    let response = "I'm sorry, I can only help with credentials, login, and password reset issues. For security reasons, I can never ask for or verify your password, OTP, or tokens. Please try selecting one of the standard help topics.";

    const normalizedQuery = query.toLowerCase();
    
    if (normalizedQuery.includes('forgot') || normalizedQuery.includes('password')) {
      response = helpTopics[0].answer;
    } else if (normalizedQuery.includes('how') || normalizedQuery.includes('reset')) {
      response = helpTopics[1].answer;
    } else if (normalizedQuery.includes('receive') || normalizedQuery.includes('email') || normalizedQuery.includes('inbox') || normalizedQuery.includes('mail')) {
      response = helpTopics[2].answer;
    } else if (normalizedQuery.includes('recognize') || normalizedQuery.includes('not exist') || normalizedQuery.includes('find my account')) {
      response = helpTopics[3].answer;
    }

    setChatHistory((prev) => [
      ...prev,
      { sender: 'user', text: query },
      { sender: 'assistant', text: response },
    ]);

    e.target.reset();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!email) {
      setError('Email is required.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await forgotPassword(email);
      setSubmitting(false);

      if (res.success) {
        setSuccessMsg(res.message || 'If that email exists, a password reset link has been sent.');
      }
    } catch (err) {
      setSubmitting(false);
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background blobs for premium glassmorphism aesthetic */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-600/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 pointer-events-none"></div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <div className="flex justify-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center shadow-lg shadow-primary-500/20">
            <span className="text-white font-extrabold text-lg">T</span>
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            Task<span className="text-primary-400">Circle</span>
          </h2>
        </div>
        <p className="text-center text-sm text-dark-400">
          Reset your password securely to regain workspace access.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-lg relative z-10 px-4 flex flex-col gap-6">
        <div className="bg-dark-900/40 backdrop-blur-xl border border-dark-800 rounded-2xl p-8 shadow-2xl">
          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-400">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-xl text-sm text-green-400">
              {successMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wider text-dark-400 mb-2">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-dark-500">
                  <Mail size={16} />
                </div>
                <input
                  id="email"
                  type="email"
                  required
                  placeholder="john@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-dark-800 border border-dark-700 rounded-xl pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary-500 transition-colors placeholder-dark-500 text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-primary-500 hover:bg-primary-600 text-white font-medium py-3 px-4 rounded-xl transition-all duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-primary-500/20"
            >
              {submitting ? 'Sending Link...' : 'Send Reset Link'}
            </button>
          </form>

          <div className="mt-6 flex justify-between items-center text-sm">
            <Link to="/login" className="text-dark-400 hover:text-white transition-colors flex items-center gap-1.5">
              <ArrowLeft size={16} /> Back to Login
            </Link>
            <button
              type="button"
              onClick={() => setShowHelp(!showHelp)}
              className="text-primary-400 hover:text-primary-300 font-semibold flex items-center gap-1.5"
            >
              <HelpCircle size={16} /> {showHelp ? 'Hide Assistant' : 'Need Help?'}
            </button>
          </div>
        </div>

        {/* AI Help Assistant Panel */}
        {showHelp && (
          <div className="bg-dark-900/40 backdrop-blur-xl border border-dark-800 rounded-2xl p-6 shadow-2xl flex flex-col gap-4 animate-fade-in">
            <div className="flex items-center gap-2 border-b border-dark-800 pb-3">
              <div className="w-8 h-8 rounded-lg bg-primary-500/10 text-primary-400 flex items-center justify-center">
                <MessageSquare size={16} />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Login Support Assistant</h3>
                <p className="text-[10px] text-dark-500">Secure automated assistant (never asks for sensitive data)</p>
              </div>
            </div>

            {/* Chat Box */}
            <div className="max-h-60 overflow-y-auto space-y-3 p-2 bg-dark-950/50 rounded-xl border border-dark-800">
              {chatHistory.map((chat, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col max-w-[85%] rounded-2xl px-4 py-2.5 text-xs ${
                    chat.sender === 'user'
                      ? 'bg-primary-600 text-white ml-auto rounded-tr-none'
                      : 'bg-dark-800 text-dark-200 mr-auto rounded-tl-none border border-dark-700'
                  }`}
                >
                  <p>{chat.text}</p>
                </div>
              ))}
            </div>

            {/* Suggestions */}
            <div className="flex flex-wrap gap-2">
              {helpTopics.map((topic, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleHelpClick(topic)}
                  className="text-[11px] font-medium bg-dark-800 hover:bg-dark-700 border border-dark-700 hover:border-dark-600 text-dark-300 hover:text-white px-3 py-1.5 rounded-full transition-all text-left"
                >
                  {topic.question}
                </button>
              ))}
            </div>

            {/* Custom Query Input */}
            <form onSubmit={handleCustomQuestion} className="flex gap-2">
              <input
                type="text"
                name="customQuery"
                placeholder="Ask support a question..."
                className="flex-1 bg-dark-800 border border-dark-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-primary-500 placeholder-dark-500"
              />
              <button
                type="submit"
                className="bg-dark-700 hover:bg-dark-600 border border-dark-600 text-white font-semibold text-xs px-4 py-2 rounded-xl transition-colors"
              >
                Ask
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

export default ForgotPassword;
